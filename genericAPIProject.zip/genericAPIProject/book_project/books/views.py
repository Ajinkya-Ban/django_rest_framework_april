from rest_framework import generics
from .models import Book
from .serializers import BookSerializer


# Create your views here.
class BookListCreateViews(generics.ListCreateAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

class BookUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

