from django.contrib import admin
from django.urls import path
from .views import BookListCreateViews, BookUpdateDestroyView
urlpatterns = [
    path('books/',BookListCreateViews.as_view(), name="book-list"),
    path('books/<int:pk>/', BookUpdateDestroyView.as_view(), name="book-details")
]